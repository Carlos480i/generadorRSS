<?php
	$numArt = $_GET['numArt'];
	$html = "";
	$url = $_GET['url'];
	$resize_buttons = $_GET['resize_buttons'];
	$xml = simplexml_load_file($url);
	$html .= "";
	$array[] = null;
		
	foreach($xml->channel->item as $item){
		$array[] = $item;
	}
	
	$item = $array[$numArt];
	$title = $item->title;
	$link = $item->link;
	$content = $item->children('http://purl.org/rss/1.0/modules/content/');	
	if($content == ''){
		$content = $item->description;
	}
	
	$html = "
		<!doctype html>
		<html lang='es'>
			<head>
				<meta charset='utf-8' />
				<meta http-equiv='x-ua-compatible' content='ie=edge'>
				<meta name='viewport' content='width=device-width, initial-scale=1.0'>
				<title>Feed</title>
				<link rel='stylesheet' href='./css/contentStyle.css'>
			</head>
			<body>
				<div>
				
					<div id='titulo'>
						<h1>$title</h1>
					</div>
					
					<div id='contenido'>
						$content
					</div>
					
					<br>
					
					<div id='link'>
						<a href='$link'>Leer la noticia en la fuente.</a>
					</div>
					
				</div>
			</body>
		</html>
	";
	
	$html_Resize = "
		<!doctype html>
		<html lang='es'>
			<head>
				<meta charset='utf-8' />
				<meta http-equiv='x-ua-compatible' content='ie=edge'>
				<meta name='viewport' content='width=device-width, initial-scale=1.0'>
				<title>Feed</title>
				<link rel='stylesheet' href='./css/contentStyle.css'>
				<script>
					function resizeText(multiplier) {
						var cuerpo = document.getElementById('contenido');
						if (cuerpo.style.fontSize == '') {
							cuerpo.style.fontSize = '1.0em';
						}
						cuerpo.style.fontSize = parseFloat(cuerpo.style.fontSize) + (multiplier * 0.1) + 'em';
					}
				</script>
			</head>
			<body>
				<div>
				
					<div id='titulo'>
						<h1>$title</h1>
					</div>
					
					<div id='contenido'>
						$content
					</div>
					
					<br>
					
					<div id='link'>
						<a href='$link'>Leer la noticia en la fuente.</a>
					</div>
					
					<div class='centrar_resizer' align='center'>
						<div class='resizer'>
							<span id='minustext' onclick='resizeText(-1)'>a</span>   |   <span id='returntop' onclick='window.history.back();'>Volver</span>   |   <span id='plustext' onclick='resizeText(1)'>A</span>
						</div>
					</div>
					
				</div>
			</body>
		</html>
	";

if($resize_buttons == "true"){
	echo $html_Resize;
}else{
	echo $html;
}
?>