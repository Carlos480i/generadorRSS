<?php

	$html = "";
	$numArt = 0;
	$aux = 0;
	
//Parsear la URL para sacar el XML y los namespaces.
	$url = getInfo("preferences.txt", "url");
	$xml = file_get_contents("$url");
	if (trim($xml) == '') {
		die('La URL no es un archivo XML. Por favor introduce una URL válida.');
	}
	$xml = simplexml_load_string($xml);
	$namespaces = $xml->getNamespaces(true);
	
//Obtener si el usuario quiere los botones de redimensión.
	$resize_buttons = getInfo("preferences.txt", "resize_buttons");
	
//Calcular el numero de imágenes que hay para poner por defecto.
	$numImgDir = iterator_count(new FilesystemIterator("./assets/img", FilesystemIterator::SKIP_DOTS))-1;
	
//Llenar el HTML con el principio del documento.
	$html .= "<!doctype html>
<html class='no-js' lang='es'>
	<head>
		<meta charset='utf-8' />
		<meta http-equiv='x-ua-compatible' content='ie=edge'>
		<meta name='viewport' content='width=device-width, initial-scale=1.0'>
		<title>Feed</title>
		<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
		<link rel='stylesheet' href='assets/css/app.css'>
	</head>
	<body>
		<div class='expanded small-collapse row small-up-1 medium-up-2 large-up-3'>";

//Empezar a parsear el XMl y buscar noticias.
	foreach($xml->channel->item as $item){
		$title = $item->title;

		$imgNumber = rand(1, $numImgDir);
		while ($imgNumber == $aux){
			$imgNumber = rand(1, $numImgDir);
		}
		$aux = $imgNumber;
		$numArt++;
		
		//Primero comprueba si hay un campo en el xml llamado media y si lo hay coge la imagen.
		@$media = $item->children($namespaces['media']);
		@$media_url = $media->attributes()->url;
		
		//Si no ha encontrado una imagen antes, la busca en la descripción de la noticia.
		if(empty($media_url)){
			$description = $item->description;	
			$imgpattern = '/src="([^"]+)"/i';
			preg_match($imgpattern, $description, $matches);
			@$media_url = $matches[1];
		}
		
		//Si tampoco encuentra la imagen en la noticia, pone una por defecto.
		if(empty($media_url)){
			$media_url = "./assets/img/$imgNumber.jpg";
		}
		
		$html .= "<div class='column'>";
		
		$html .= "<a href='./content.php?numArt=$numArt&url=$url&resize_buttons=$resize_buttons'>
					<div class='box' style='background-image:url($media_url); background-size:cover; background-position:center;'>
						<h2>$title</h2>
					</div>
				</a>";
		$html .= "</div>";
	}
	
//Acabar el documento HTML con el final del código.
	$html .= "</div>
		<script src='assets/js/app.js'></script>
	</body>
</html>";

//Mostrar HTML en pantalla.
echo $html;

//Función para obtener info del archivo TXT de preferencias.;
function getInfo($file, $search_string){
	$lines_array = file($file);

	foreach($lines_array as $line) {
		if(strpos($line, $search_string) !== false) {
			list(, $new_str) = explode("=", $line);
			// If you don't want the space before the word bong, uncomment the following line.
			$new_str = trim($new_str);
		}
	}
	return $new_str;
}

?>